﻿namespace Newtonsoft.Json.Tests.TestObjects
{
  public abstract class ContentBaseClass
  {
  }
}
